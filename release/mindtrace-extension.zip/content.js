/**
 * MindTrace — Content Script
 * 划词记录、思维证据（粘贴/拖拽/右键图片/截图）、保存提示
 */

(function () {
  'use strict';

  if (window.__MINDTRACE_INJECTED__) {
    return;
  }
  window.__MINDTRACE_INJECTED__ = true;

  const ROOT_ID = 'mindtrace-root';
  const MIN_SELECTION_LENGTH = 2;
  const TOAST_DURATION = 2500;
  const MAX_EVIDENCE_IMAGES = 5;
  const PANEL_EDGE_GAP = 12;

  let currentSelectedText = '';
  /** @type {{ blob: Blob, previewUrl: string }[]} */
  let pendingEvidence = [];
  /** @type {'selection'|'image'|'quick'} */
  let panelMode = 'selection';
  /** @type {string|null} */
  let pendingRelationRecordId = null;

  let rootEl = null;
  let triggerBtn = null;
  let panelEl = null;
  let toastEl = null;
  let panelDragging = false;
  let panelDragOffsetX = 0;
  let panelDragOffsetY = 0;

  function init() {
    if (document.getElementById(ROOT_ID)) {
      return;
    }

    rootEl = document.createElement('div');
    rootEl.id = ROOT_ID;
    rootEl.setAttribute('data-mindtrace', 'host');

    triggerBtn = document.createElement('button');
    triggerBtn.type = 'button';
    triggerBtn.className = 'mt-trigger-btn';
    triggerBtn.textContent = getText('captureIdea');
    triggerBtn.setAttribute('aria-label', getText('captureIdeaAria'));
    triggerBtn.hidden = true;
    triggerBtn.addEventListener('click', onTriggerClick);

    panelEl = buildPanel();
    panelEl.hidden = true;

    toastEl = document.createElement('div');
    toastEl.className = 'mt-toast';
    toastEl.setAttribute('role', 'status');
    toastEl.hidden = true;

    rootEl.appendChild(triggerBtn);
    rootEl.appendChild(panelEl);
    rootEl.appendChild(toastEl);

    document.documentElement.appendChild(rootEl);

    bindDocumentEvents();

    chrome.runtime.onMessage.addListener((message) => {
      if (!message || !message.type) {
        return;
      }
      if (message.type === 'mindtrace-open-image-save') {
        openImageSavePanel(message.srcUrl, {
          pageTitle: message.pageTitle,
          pageUrl: message.pageUrl,
        });
      } else if (message.type === 'mindtrace-open-selection') {
        openSelectionFromCommand();
      } else if (message.type === 'mindtrace-open-quick-note') {
        openQuickNotePanel();
      }
    });
  }

  function buildPanel() {
    const panel = document.createElement('div');
    panel.className = 'mt-panel';
    panel.innerHTML = `
      <div class="mt-panel-header">
        <div class="mt-panel-heading">
          <span class="mt-panel-title" data-ref="panel-title" data-i18n="captureIdea">Capture Idea</span>
          <p class="mt-panel-subtitle" data-ref="panel-subtitle" hidden></p>
        </div>
        <button type="button" class="mt-panel-close" data-i18n-aria="close" aria-label="Close">×</button>
      </div>
      <div class="mt-panel-body">
        <div class="mt-quote-wrap" data-ref="quote-wrap">
          <label class="mt-label" data-i18n="originalText">Original text</label>
          <blockquote class="mt-quote" data-ref="quote"></blockquote>
        </div>
        <div class="mt-garden-field" data-ref="garden-field">
          <label class="mt-label" for="mt-garden-select" data-i18n="cognitiveGarden">Mind Garden</label>
          <select id="mt-garden-select" class="mt-garden-select" data-ref="garden-select" data-i18n-aria="selectGardenAria" aria-label="Select mind garden"></select>
          <button type="button" class="mt-btn-link mt-garden-new" data-action="new-garden" data-i18n="newGardenBtn" data-i18n-title="newGardenTitle" title="Quickly create a new garden">+ New Garden</button>
        </div>
        <label class="mt-label" for="mt-note-input" data-ref="note-label" data-i18n="noteLabel">Your note</label>
        <textarea
          id="mt-note-input"
          class="mt-note-input"
          rows="4"
          data-i18n-placeholder="notePlaceholder"
          placeholder="What came to mind…"
          data-ref="note"
        ></textarea>
        <div class="mt-evidence" data-ref="evidence-section">
          <label class="mt-label" data-i18n="inspirationScene">Inspiration scene</label>
          <p class="mt-evidence-hint" data-i18n="evidenceHint">Paste, drag in, or capture the screen</p>
          <div class="mt-evidence-preview" data-ref="evidence-preview" hidden></div>
          <div class="mt-evidence-actions">
            <button type="button" class="mt-btn-link" data-action="capture-moment" data-i18n="captureScreen" data-i18n-title="captureScreenTitle" title="Capture the visible webpage">
              Capture visible page
            </button>
          </div>
        </div>
      </div>
      <div class="mt-panel-footer" data-ref="panel-footer">
        <button type="button" class="mt-btn mt-btn-secondary" data-action="cancel" data-i18n="cancel">Cancel</button>
        <button type="button" class="mt-btn mt-btn-primary" data-action="save" data-i18n="save">Save</button>
      </div>
      <div class="mt-relation-step" data-ref="relation-step" hidden>
        <p class="mt-relation-title" data-i18n="relationSimilarTitle">Similar to these thoughts</p>
        <p class="mt-relation-hint" data-i18n="relationSimilarHint">Check past ideas to link (optional)</p>
        <div class="mt-relation-list" data-ref="relation-list"></div>
        <div class="mt-relation-actions">
          <button type="button" class="mt-btn mt-btn-secondary" data-action="relation-skip" data-i18n="relationSkip">Skip</button>
          <button type="button" class="mt-btn mt-btn-primary" data-action="relation-confirm" data-i18n="relationConfirm">Confirm links</button>
        </div>
      </div>
    `;

    MindTraceI18n.applyPageI18n(panel);

    panel.querySelector('.mt-panel-close').addEventListener('click', hidePanel);
    panel.querySelector('[data-action="cancel"]').addEventListener('click', hidePanel);
    panel.querySelector('[data-action="save"]').addEventListener('click', onSaveClick);
    panel
      .querySelector('[data-action="relation-skip"]')
      .addEventListener('click', onRelationSkip);
    panel
      .querySelector('[data-action="relation-confirm"]')
      .addEventListener('click', onRelationConfirm);
    panel
      .querySelector('[data-action="new-garden"]')
      .addEventListener('click', onQuickCreateGardenClick);
    panel
      .querySelector('[data-action="capture-moment"]')
      .addEventListener('click', onCaptureMomentClick);
    panel
      .querySelector('.mt-panel-header')
      .addEventListener('mousedown', onPanelHeaderMouseDown);

    const noteInput = panel.querySelector('[data-ref="note"]');
    noteInput.addEventListener('paste', onNotePaste);
    panel.addEventListener('dragover', onPanelDragOver);
    panel.addEventListener('dragleave', onPanelDragLeave);
    panel.addEventListener('drop', onPanelDrop);

    return panel;
  }

  function bindDocumentEvents() {
    document.addEventListener('mouseup', onMouseUp, true);
    document.addEventListener('mousemove', onMouseMove, true);
    document.addEventListener('mousedown', onMouseDown, true);
    document.addEventListener('keydown', onKeyDown, true);
    window.addEventListener('scroll', hideTriggerButton, { passive: true });
    window.addEventListener('resize', onWindowResize, { passive: true });
  }

  function onMouseUp(event) {
    if (panelDragging) {
      stopPanelDrag();
      return;
    }
    if (isInsideMindTraceUI(event.target)) {
      return;
    }

    requestAnimationFrame(() => {
      const selection = window.getSelection();
      const text = selection ? selection.toString().trim() : '';

      if (text.length < MIN_SELECTION_LENGTH) {
        hideTriggerButton();
        return;
      }

      if (isSelectionInEditable(selection)) {
        hideTriggerButton();
        return;
      }

      currentSelectedText = text;
      showTriggerButton(selection);
    });
  }

  function onMouseDown(event) {
    if (isInsideMindTraceUI(event.target)) {
      return;
    }
    if (!panelEl || panelEl.hidden) {
      return;
    }
    if (panelEl.dataset.relationActive === '1') {
      return;
    }
    hidePanel();
  }

  function onMouseMove(event) {
    if (!panelDragging || !panelEl) {
      return;
    }
    event.preventDefault();
    const left = event.clientX - panelDragOffsetX;
    const top = event.clientY - panelDragOffsetY;
    setPanelPosition(left, top);
  }

  function onWindowResize() {
    hideTriggerButton();
    if (!panelEl || panelEl.hidden) {
      return;
    }
    const left = Number.parseFloat(panelEl.style.left || '0');
    const top = Number.parseFloat(panelEl.style.top || '0');
    if (!Number.isFinite(left) || !Number.isFinite(top)) {
      applyDefaultPanelPosition();
      return;
    }
    setPanelPosition(left, top);
  }

  function onPanelHeaderMouseDown(event) {
    if (!panelEl || panelEl.hidden) {
      return;
    }
    if (event.button !== 0) {
      return;
    }
    const target = /** @type {Element} */ (event.target);
    if (target && target.closest('.mt-panel-close')) {
      return;
    }
    const rect = panelEl.getBoundingClientRect();
    panelDragging = true;
    panelDragOffsetX = event.clientX - rect.left;
    panelDragOffsetY = event.clientY - rect.top;
    panelEl.classList.add('is-dragging');
    event.preventDefault();
  }

  function stopPanelDrag() {
    panelDragging = false;
    if (panelEl) {
      panelEl.classList.remove('is-dragging');
      panelEl.dataset.userMoved = '1';
    }
  }

  function setPanelPosition(left, top) {
    if (!panelEl) {
      return;
    }
    const width = panelEl.offsetWidth || 400;
    const height = panelEl.offsetHeight || 320;
    const maxLeft = Math.max(PANEL_EDGE_GAP, window.innerWidth - width - PANEL_EDGE_GAP);
    const maxTop = Math.max(PANEL_EDGE_GAP, window.innerHeight - height - PANEL_EDGE_GAP);
    const clampedLeft = Math.min(Math.max(PANEL_EDGE_GAP, left), maxLeft);
    const clampedTop = Math.min(Math.max(PANEL_EDGE_GAP, top), maxTop);

    panelEl.style.left = `${clampedLeft}px`;
    panelEl.style.top = `${clampedTop}px`;
    panelEl.style.transform = 'none';
  }

  function applyDefaultPanelPosition() {
    if (!panelEl) {
      return;
    }
    const width = panelEl.offsetWidth || 400;
    const left = Math.max(PANEL_EDGE_GAP, (window.innerWidth - width) / 2);
    const top = Math.max(80, window.innerHeight * 0.12);
    setPanelPosition(left, top);
    delete panelEl.dataset.userMoved;
  }

  function onKeyDown(event) {
    if (event.key === 'Escape') {
      hidePanel();
      hideTriggerButton();
    }
  }

  function isSelectionInEditable(selection) {
    if (!selection || selection.rangeCount === 0) {
      return false;
    }
    let node = selection.anchorNode;
    while (node) {
      if (node.nodeType === Node.ELEMENT_NODE) {
        const el = /** @type {Element} */ (node);
        if (
          el.isContentEditable ||
          el.tagName === 'INPUT' ||
          el.tagName === 'TEXTAREA' ||
          el.tagName === 'SELECT'
        ) {
          return true;
        }
      }
      node = node.parentNode;
    }
    return false;
  }

  function isInsideMindTraceUI(target) {
    const host = document.getElementById(ROOT_ID);
    if (!host || !target) {
      return false;
    }
    return host.contains(/** @type {Node} */ (target));
  }

  function showTriggerButton(selection) {
    if (!triggerBtn || !selection || selection.rangeCount === 0) {
      return;
    }

    const range = selection.getRangeAt(0);
    const rect = range.getBoundingClientRect();

    if (rect.width === 0 && rect.height === 0) {
      hideTriggerButton();
      return;
    }

    const btnWidth = 88;
    const btnHeight = 32;
    const padding = 8;

    let top = rect.bottom + padding;
    let left = rect.left + rect.width / 2 - btnWidth / 2;

    const maxLeft = window.innerWidth - btnWidth - padding;
    const minLeft = padding;
    left = Math.max(minLeft, Math.min(left, maxLeft));

    if (rect.bottom + btnHeight + padding > window.innerHeight) {
      top = rect.top - btnHeight - padding;
    }

    triggerBtn.style.top = `${top}px`;
    triggerBtn.style.left = `${left}px`;
    triggerBtn.hidden = false;
  }

  function hideTriggerButton() {
    if (triggerBtn) {
      triggerBtn.hidden = true;
    }
  }

  function onTriggerClick(event) {
    event.stopPropagation();
    hideTriggerButton();
    openSelectionPanel();
  }

  function clearPendingEvidence() {
    pendingEvidence.forEach((item) => {
      if (item.previewUrl) {
        URL.revokeObjectURL(item.previewUrl);
      }
    });
    pendingEvidence = [];
    renderEvidencePreview();
  }

  function setPanelMode(mode) {
    panelMode = mode;
    const titleEl = panelEl.querySelector('[data-ref="panel-title"]');
    const subtitleEl = panelEl.querySelector('[data-ref="panel-subtitle"]');
    const quoteWrap = panelEl.querySelector('[data-ref="quote-wrap"]');
    const noteLabel = panelEl.querySelector('[data-ref="note-label"]');
    const noteInput = panelEl.querySelector('[data-ref="note"]');

    if (mode === 'quick') {
      if (titleEl) {
        titleEl.textContent = getText('quickNoteTitle');
      }
      if (subtitleEl) {
        subtitleEl.textContent = getText('quickNoteSubtitle');
        subtitleEl.hidden = false;
      }
      if (quoteWrap) {
        quoteWrap.hidden = true;
      }
      if (noteLabel) {
        noteLabel.textContent = getText('noteLabel');
      }
      if (noteInput) {
        noteInput.placeholder = getText('quickNotePlaceholder');
      }
    } else if (mode === 'image') {
      if (titleEl) {
        titleEl.textContent = getText('imageCaptureTitle');
      }
      if (subtitleEl) {
        subtitleEl.textContent = getText('imageCaptureSubtitle');
        subtitleEl.hidden = false;
      }
      if (quoteWrap) {
        quoteWrap.hidden = true;
      }
      if (noteLabel) {
        noteLabel.textContent = getText('noteLabel');
      }
      if (noteInput) {
        noteInput.placeholder = getText('imageNotePlaceholder');
      }
    } else {
      if (titleEl) {
        titleEl.textContent = getText('captureIdea');
      }
      if (subtitleEl) {
        subtitleEl.textContent = '';
        subtitleEl.hidden = true;
      }
      if (quoteWrap) {
        quoteWrap.hidden = false;
      }
      if (noteLabel) {
        noteLabel.textContent = getText('noteLabel');
      }
      if (noteInput) {
        noteInput.placeholder = getText('notePlaceholder');
      }
    }
  }

  function openSelectionFromCommand() {
    const selection = window.getSelection();
    const text = selection ? selection.toString().trim() : '';
    if (text.length < MIN_SELECTION_LENGTH) {
      showToast(getText('selectMinChars'));
      return;
    }
    currentSelectedText = text;
    hideTriggerButton();
    openSelectionPanel();
  }

  function openQuickNotePanel() {
    if (!panelEl) {
      return;
    }
    hideTriggerButton();
    setPanelMode('quick');
    clearPendingEvidence();
    panelEl.dataset.sourceImageUrl = '';
    currentSelectedText = '';
    const noteInput = panelEl.querySelector('[data-ref="note"]');
    if (noteInput) {
      noteInput.value = '';
    }
    hideRelationStep();
    showPanel();
  }

  function openSelectionPanel() {
    if (!panelEl) {
      return;
    }

    setPanelMode('selection');
    hideRelationStep();
    clearPendingEvidence();
    panelEl.dataset.sourceImageUrl = '';

    const quoteEl = panelEl.querySelector('[data-ref="quote"]');
    const noteInput = panelEl.querySelector('[data-ref="note"]');

    if (quoteEl) {
      quoteEl.textContent = currentSelectedText;
    }
    if (noteInput) {
      noteInput.value = '';
    }

    showPanel();
  }

  /**
   * @param {string} srcUrl
   * @param {{ pageTitle?: string, pageUrl?: string }} meta
   */
  async function openImageSavePanel(srcUrl, meta) {
    if (!panelEl) {
      return;
    }

    hideTriggerButton();
    setPanelMode('image');
    hideRelationStep();
    clearPendingEvidence();
    currentSelectedText = '';

    panelEl.dataset.pageTitle = meta.pageTitle || document.title;
    panelEl.dataset.pageUrl = meta.pageUrl || window.location.href;
    panelEl.dataset.sourceImageUrl = srcUrl || '';

    const noteInput = panelEl.querySelector('[data-ref="note"]');
    if (noteInput) {
      noteInput.value = '';
    }

    showPanel();

    try {
      const blob = await imageUrlToBlob(srcUrl);
      if (blob) {
        addEvidenceBlob(blob);
      } else {
        showToast(getText('imageReadFailed'));
      }
    } catch (err) {
      console.warn('[MindTrace] image fetch failed:', err);
      showToast(getText('imageReadFailedAlt'));
    }

    if (noteInput) {
      noteInput.focus();
    }
  }

  /**
   * 填充认知花园下拉（默认选中最近使用的花园）
   */
  async function populateGardenSelect() {
    if (!panelEl || typeof MindTraceGardenService === 'undefined') {
      return;
    }
    const select = panelEl.querySelector('[data-ref="garden-select"]');
    if (!select) {
      return;
    }
    try {
      await MindTraceGardenService.migrateIfNeeded();
      const gardens = await MindTraceGardenService.getGardens();
      const currentId = await MindTraceGardenService.getCurrentGardenId();
      select.innerHTML = gardens
        .map(
          (g) =>
            `<option value="${g.id.replace(/"/g, '&quot;')}">${(g.icon || '🌿') + ' ' + (g.name || getText('gardenDefaultName'))}</option>`
        )
        .join('');
      select.value = currentId;
    } catch (err) {
      console.warn('[MindTrace] garden select load failed:', err);
    }
  }

  async function onQuickCreateGardenClick() {
    const name = window.prompt(
      getText('newGardenPrompt'),
      getText('newGardenDefault')
    );
    if (!name || !name.trim()) {
      return;
    }
    try {
      const garden = await MindTraceGardenService.createGarden({
        name: name.trim(),
      });
      await populateGardenSelect();
      const select = panelEl.querySelector('[data-ref="garden-select"]');
      if (select) {
        select.value = garden.id;
      }
      showToast(getText('gardenCreated', [garden.name]));
    } catch (err) {
      console.warn('[MindTrace] quick create garden failed:', err);
      showToast(getText('createGardenFailed'));
    }
  }

  function showPanel() {
    populateGardenSelect();
    panelEl.hidden = false;
    if (panelEl.dataset.userMoved === '1') {
      const left = Number.parseFloat(panelEl.style.left || '0');
      const top = Number.parseFloat(panelEl.style.top || '0');
      setPanelPosition(left, top);
    } else {
      applyDefaultPanelPosition();
    }
    requestAnimationFrame(() => {
      const noteInput = panelEl.querySelector('[data-ref="note"]');
      if (noteInput) {
        noteInput.focus();
      }
    });
  }

  function hidePanel() {
    if (panelEl) {
      panelEl.hidden = true;
      panelEl.dataset.relationActive = '';
    }
    pendingRelationRecordId = null;
    hideRelationStep();
    clearPendingEvidence();
  }

  function hideRelationStep() {
    if (!panelEl) {
      return;
    }
    const step = panelEl.querySelector('[data-ref="relation-step"]');
    const body = panelEl.querySelector('.mt-panel-body');
    const footer = panelEl.querySelector('[data-ref="panel-footer"]');
    const header = panelEl.querySelector('.mt-panel-header');
    if (step) {
      step.hidden = true;
    }
    if (body) {
      body.hidden = false;
    }
    if (footer) {
      footer.hidden = false;
    }
    if (header) {
      header.hidden = false;
    }
    panelEl.dataset.relationActive = '';
  }

  /**
   * @param {InspirationRecord} savedRecord
   */
  async function showRelationPrompt(savedRecord) {
    if (
      !panelEl ||
      typeof MindTraceRelationService === 'undefined' ||
      !savedRecord ||
      !savedRecord.id
    ) {
      hidePanel();
      showToast(getText('savedToMindTrace'));
      return;
    }

    const all = await MindTraceStorage.getAll(savedRecord.gardenId);
    const others = all.filter((item) => item.id !== savedRecord.id);
    const related = MindTraceRelationService.findRelatedThoughts(
      savedRecord,
      others
    );

    if (!related.length) {
      hidePanel();
      showToast(getText('savedToMindTrace'));
      window.getSelection()?.removeAllRanges();
      return;
    }

    pendingRelationRecordId = savedRecord.id;

    const step = panelEl.querySelector('[data-ref="relation-step"]');
    const listEl = panelEl.querySelector('[data-ref="relation-list"]');
    const body = panelEl.querySelector('.mt-panel-body');
    const footer = panelEl.querySelector('[data-ref="panel-footer"]');
    const header = panelEl.querySelector('.mt-panel-header');

    if (!step || !listEl) {
      hidePanel();
      showToast(getText('savedToMindTrace'));
      return;
    }

    if (body) {
      body.hidden = true;
    }
    if (footer) {
      footer.hidden = true;
    }
    if (header) {
      header.hidden = false;
    }

    listEl.innerHTML = related
      .map(({ record, score, semantic }) => {
        const label =
          (record.note || '').trim().split('\n')[0] ||
          (record.selectedText || '').trim() ||
          record.pageTitle ||
          getText('unnamedThought');
        const short =
          label.length > 56 ? label.slice(0, 56) + '…' : label;
        const meta = semantic
          ? getText('semanticScore', [String((score * 100).toFixed(0))])
          : getText('keywordScore', [String(score)]);
        return `
          <label class="mt-relation-item">
            <input type="checkbox" value="${record.id}" />
            <span class="mt-relation-item-text">${escapeRelationText(short)}</span>
            <span class="mt-relation-item-meta">${meta}</span>
          </label>
        `;
      })
      .join('');

    step.hidden = false;
    panelEl.dataset.relationActive = '1';
    panelEl.hidden = false;
  }

  /**
   * @param {string} text
   * @returns {string}
   */
  function escapeRelationText(text) {
    if (typeof MindTraceUtils !== 'undefined') {
      return MindTraceUtils.escapeHtml(text);
    }
    return String(text)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }

  function onRelationSkip() {
    hidePanel();
    showToast(getText('savedToMindTrace'));
    window.getSelection()?.removeAllRanges();
  }

  async function onRelationConfirm() {
    const recordId = pendingRelationRecordId;
    if (!recordId || !panelEl) {
      onRelationSkip();
      return;
    }

    const checked = panelEl.querySelectorAll(
      '[data-ref="relation-list"] input[type="checkbox"]:checked'
    );
    const linkedIds = [...checked].map((el) => el.value).filter(Boolean);

    try {
      if (linkedIds.length) {
        await MindTraceStorage.updateById(recordId, {
          linkedThoughtIds: linkedIds,
        });
      }
      hidePanel();
      showToast(
        linkedIds.length
          ? getText('savedWithLinks', [String(linkedIds.length)])
          : getText('savedToMindTrace')
      );
    } catch (err) {
      console.warn('[MindTrace] link thoughts failed:', err);
      hidePanel();
      showToast(getText('savedLinkFailed'));
    }
    window.getSelection()?.removeAllRanges();
  }

  /**
   * @param {Blob} blob
   */
  function addEvidenceBlob(blob) {
    if (!blob || !blob.type.startsWith('image/')) {
      return;
    }
    if (pendingEvidence.length >= MAX_EVIDENCE_IMAGES) {
      showToast(getText('maxEvidenceImages', [String(MAX_EVIDENCE_IMAGES)]));
      return;
    }
    const previewUrl = URL.createObjectURL(blob);
    pendingEvidence.push({ blob, previewUrl });
    renderEvidencePreview();
  }

  function renderEvidencePreview() {
    const wrap = panelEl.querySelector('[data-ref="evidence-preview"]');
    if (!wrap) {
      return;
    }

    if (!pendingEvidence.length) {
      wrap.hidden = true;
      wrap.innerHTML = '';
      return;
    }

    wrap.hidden = false;
    wrap.innerHTML = pendingEvidence
      .map(
        (item, index) =>
          `<div class="mt-evidence-thumb-wrap">
            <img class="mt-evidence-thumb" src="${item.previewUrl}" alt="${MindTraceUtils.escapeHtml(getText('evidencePreviewAlt'))}" />
            <button type="button" class="mt-evidence-remove" data-index="${index}" data-i18n-aria="remove" aria-label="${MindTraceUtils.escapeHtml(getText('remove'))}">×</button>
          </div>`
      )
      .join('');

    wrap.querySelectorAll('.mt-evidence-remove').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = Number(btn.getAttribute('data-index'));
        const removed = pendingEvidence.splice(idx, 1)[0];
        if (removed && removed.previewUrl) {
          URL.revokeObjectURL(removed.previewUrl);
        }
        renderEvidencePreview();
      });
    });
  }

  function onNotePaste(event) {
    const items = event.clipboardData && event.clipboardData.items;
    if (!items) {
      return;
    }

    let hasImage = false;
    for (const item of items) {
      if (item.type.startsWith('image/')) {
        hasImage = true;
        const file = item.getAsFile();
        if (file) {
          addEvidenceBlob(file);
        }
      }
    }

    if (hasImage) {
      event.preventDefault();
    }
  }

  function onPanelDragOver(event) {
    if (!hasFileDrag(event)) {
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    panelEl.classList.add('mt-panel-dragover');
  }

  function onPanelDragLeave(event) {
    event.stopPropagation();
    panelEl.classList.remove('mt-panel-dragover');
  }

  function onPanelDrop(event) {
    if (!hasFileDrag(event)) {
      return;
    }
    event.preventDefault();
    event.stopPropagation();
    panelEl.classList.remove('mt-panel-dragover');

    const files = event.dataTransfer && event.dataTransfer.files;
    if (!files) {
      return;
    }

    for (const file of files) {
      if (file.type.startsWith('image/')) {
        addEvidenceBlob(file);
      }
    }
  }

  function hasFileDrag(event) {
    const types = event.dataTransfer && event.dataTransfer.types;
    return types && Array.from(types).includes('Files');
  }

  async function onCaptureMomentClick() {
    const saveBtn = panelEl.querySelector('[data-action="capture-moment"]');
    if (saveBtn) {
      saveBtn.disabled = true;
    }

    try {
      const response = await chrome.runtime.sendMessage({
        type: 'mindtrace-capture-visible-tab',
      });

      if (!response || !response.ok || !response.dataUrl) {
        showToast(getText('captureFailedActiveTab'));
        return;
      }

      const blob = await dataUrlToBlob(response.dataUrl);
      addEvidenceBlob(blob);
      showToast(getText('pageCaptured'));
    } catch (err) {
      console.warn('[MindTrace] capture moment failed:', err);
      showToast(getText('captureFailed'));
    } finally {
      if (saveBtn) {
        saveBtn.disabled = false;
      }
    }
  }

  /**
   * @param {string} dataUrl
   * @returns {Promise<Blob>}
   */
  function dataUrlToBlob(dataUrl) {
    return fetch(dataUrl).then((r) => r.blob());
  }

  /**
   * @param {string} url
   * @returns {Promise<Blob|null>}
   */
  async function imageUrlToBlob(url) {
    try {
      const res = await fetch(url);
      if (res.ok) {
        return await res.blob();
      }
    } catch (_e) {
      /* cross-origin: try canvas */
    }

    const img = await loadImageElement(url);
    if (!img) {
      return null;
    }

    try {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth || img.width;
      canvas.height = img.naturalHeight || img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        return null;
      }
      ctx.drawImage(img, 0, 0);
      return await new Promise((resolve) => {
        canvas.toBlob((blob) => resolve(blob), 'image/png');
      });
    } catch (err) {
      console.warn('[MindTrace] canvas export failed:', err);
      return null;
    }
  }

  /**
   * @param {string} url
   * @returns {Promise<HTMLImageElement|null>}
   */
  function loadImageElement(url) {
    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => resolve(img);
      img.onerror = () => {
        const fallback = Array.from(document.images).find(
          (el) => el.src === url || el.currentSrc === url
        );
        if (fallback && fallback.complete) {
          resolve(fallback);
        } else {
          resolve(null);
        }
      };
      img.src = url;
    });
  }

  async function onSaveClick() {
    const noteInput = panelEl.querySelector('[data-ref="note"]');
    const note = noteInput ? noteInput.value.trim() : '';

    const pageTitle =
      panelMode === 'image' && panelEl.dataset.pageTitle
        ? panelEl.dataset.pageTitle
        : document.title;
    const pageUrl =
      panelMode === 'image' && panelEl.dataset.pageUrl
        ? panelEl.dataset.pageUrl
        : window.location.href;
    const sourceImageUrl =
      panelMode === 'image' ? (panelEl.dataset.sourceImageUrl || '').trim() : '';

    const gardenSelect = panelEl.querySelector('[data-ref="garden-select"]');
    const gardenId =
      gardenSelect && gardenSelect.value
        ? gardenSelect.value
        : await MindTraceGardenService.getCurrentGardenId();

    if (typeof MindTraceGardenService !== 'undefined' && gardenId) {
      await MindTraceGardenService.setCurrentGardenId(gardenId);
    }

    const blobs = pendingEvidence.map((item) => item.blob);

    const record = MindTraceUtils.buildRecord({
      selectedText: panelMode === 'selection' ? currentSelectedText : '',
      note,
      pageTitle,
      pageUrl,
      gardenId,
      previewImageUrl: sourceImageUrl,
      userEvidence: blobs.length > 0 || Boolean(sourceImageUrl),
    });

    if (!MindTraceUtils.hasRequiredThought(record)) {
      showToast(getText('saveValidation'));
      if (noteInput) {
        noteInput.focus();
      }
      return;
    }

    const saveBtn = panelEl.querySelector('[data-action="save"]');
    if (saveBtn) {
      saveBtn.disabled = true;
      saveBtn.textContent = getText('saving');
    }

    try {
      const saved = await MindTraceStorage.save(record, { imageBlobs: blobs });
      if (saveBtn) {
        saveBtn.disabled = false;
        saveBtn.textContent = getText('save');
      }
      await showRelationPrompt(saved);
    } catch (err) {
      console.error('[MindTrace] 保存失败:', err);
      if (err && err.message === 'THOUGHT_CONTENT_REQUIRED') {
        showToast(getText('saveValidation'));
      } else {
        showToast(getText('saveFailedRetry'));
      }
    } finally {
      if (saveBtn) {
        saveBtn.disabled = false;
        saveBtn.textContent = getText('save');
      }
    }
  }

  function showToast(message) {
    if (!toastEl) {
      return;
    }
    toastEl.textContent = message;
    toastEl.hidden = false;
    toastEl.classList.add('mt-toast-visible');

    clearTimeout(showToast._timer);
    showToast._timer = setTimeout(() => {
      toastEl.classList.remove('mt-toast-visible');
      toastEl.hidden = true;
    }, TOAST_DURATION);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
